$(document).ready(function(){

  $('.toast').toast('show');

  // $('.collapse').collapse()

    
});


