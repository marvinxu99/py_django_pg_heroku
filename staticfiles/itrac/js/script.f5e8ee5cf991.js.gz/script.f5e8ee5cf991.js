$(document).ready(function(){
    $('select').formSelect();
    $('.sidenav').sidenav();
    $('.collapsible').collapsible({
        accordion : true
      });
    $('.materialboxed').materialbox();
    $('.modal').modal();
    $('.tabs').tabs();
  });